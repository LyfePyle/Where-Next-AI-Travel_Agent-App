'use client';

import { useState, useEffect } from 'react';
import { Calendar, MapPin, Users, DollarSign, Plane, Hotel, Star, Clock, Wifi, Car } from 'lucide-react';
import { useTripBudget, type TripSelection } from '@/hooks/useTripBudget';
import TravelHacksPanel from './TravelHacksPanel';
import PriceTrackingPanel from './PriceTrackingPanel';
import BookingOptionsPanel from './BookingOptionsPanel';
import { analytics } from '@/lib/analytics';

// Helper function to get destination-appropriate names
const getHotelName = (destination: string, tier: string) => {
  const city = destination.split(',')[0].trim();
  
  if (city.toLowerCase().includes('cancun')) {
    return tier === 'luxury' ? 'The Ritz-Carlton Cancun' : 
           tier === 'budget' ? 'Cancun Beach Resort' : 'Fiesta Americana Cancun';
  }
  
  if (city.toLowerCase().includes('honolulu')) {
    return tier === 'luxury' ? 'Four Seasons Resort Oahu' : 
           tier === 'budget' ? 'Waikiki Beach Hotel' : 'Royal Hawaiian Hotel';
  }
  
  // Default fallback
  return tier === 'luxury' ? `Grand ${city} Palace` : 
         tier === 'budget' ? `Budget Hotel ${city}` : `Hotel ${city} Plaza`;
};

const getAirlineName = (destination: string, index: number) => {
  const city = destination.split(',')[0].trim();
  
  if (city.toLowerCase().includes('cancun')) {
    return ['Air Canada', 'WestJet', 'Sunwing'][index] || 'Air Canada';
  }
  
  if (city.toLowerCase().includes('honolulu')) {
    return ['Air Canada', 'WestJet', 'Hawaiian Airlines'][index] || 'Air Canada';
  }
  
  return ['Air Canada', 'Lufthansa', 'KLM'][index] || 'Air Canada';
};

const getDestinationPricing = (destination: string) => {
  const city = destination.split(',')[0].trim();
  
  if (city.toLowerCase().includes('cancun')) {
    return {
      flights: [850, 650, 1200],
      hotels: [180, 120, 350]
    };
  }
  
  if (city.toLowerCase().includes('honolulu')) {
    return {
      flights: [950, 750, 1400], 
      hotels: [220, 140, 450]
    };
  }
  
  // Default pricing
  return {
    flights: [850, 720, 980],
    hotels: [180, 140, 280]
  };
};

const getFlightDuration = (destination: string, flightType: 'direct' | 'one-stop' | 'premium') => {
  const city = destination.split(',')[0].trim().toLowerCase();
  
  // Mexico destinations (Cancun, Acapulco, etc.)
  if (city.includes('cancun') || city.includes('acapulco') || city.includes('puerto vallarta')) {
    return {
      direct: '6h 30m',
      'one-stop': '9h 15m', 
      premium: '5h 45m'
    }[flightType];
  }
  
  // Hawaii
  if (city.includes('honolulu') || city.includes('maui')) {
    return {
      direct: '9h 20m',
      'one-stop': '12h 30m',
      premium: '8h 45m'
    }[flightType];
  }
  
  // Europe destinations
  if (city.includes('london') || city.includes('paris') || city.includes('madrid')) {
    return {
      direct: '9h 45m',
      'one-stop': '13h 20m',
      premium: '9h 15m'
    }[flightType];
  }
  
  // Asia destinations
  if (city.includes('tokyo') || city.includes('bangkok') || city.includes('singapore')) {
    return {
      direct: '11h 30m',
      'one-stop': '16h 45m',
      premium: '10h 50m'
    }[flightType];
  }
  
  // Default (medium-distance destinations)
  return {
    direct: '8h 30m',
    'one-stop': '12h 15m',
    premium: '7h 45m'
  }[flightType];
};

interface FlightOption {
  id: string;
  airline: string;
  price: number;
  duration: string;
  departure: string;
  arrival: string;
  stops: number;
  aircraft: string;
}

interface HotelOption {
  id: string;
  name: string;
  rating: number;
  pricePerNight: number;
  totalPrice: number;
  area: string;
  amenities: string[];
  image: string;
  description: string;
}

interface TripDetailsEnhancedProps {
  tripId: string;
  destination: string;
  startDate: string;
  endDate: string;
  travelers: { adults: number; kids: number };
  onSaveTrip?: (tripData: TripSelection) => void;
}

export default function TripDetailsEnhanced({ 
  tripId, 
  destination, 
  startDate, 
  endDate, 
  travelers,
  onSaveTrip 
}: TripDetailsEnhancedProps) {
  const [selectedFlightId, setSelectedFlightId] = useState<string>('');
  const [selectedHotelId, setSelectedHotelId] = useState<string>('');
  const [flightOptions, setFlightOptions] = useState<FlightOption[]>([]);
  const [hotelOptions, setHotelOptions] = useState<HotelOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Calculate trip duration
  const tripDuration = Math.ceil(
    (new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24)
  );

  // Create trip selection for budget calculation
  const tripSelection: TripSelection = {
    id: tripId,
    destination,
    startDate,
    endDate,
    selectedFlight: flightOptions.find(f => f.id === selectedFlightId),
    selectedHotel: hotelOptions.find(h => h.id === selectedHotelId),
    travelers
  };

  // Use the budget hook for real-time calculations
  const budgetData = useTripBudget({ trip: tripSelection });

  useEffect(() => {
    loadTripOptions();
    
    // Track trip details view
    analytics.tripPlanned(destination, { departure: startDate, return: endDate }, travelers.adults);
  }, [destination, startDate, endDate, travelers]);

  const loadTripOptions = async () => {
    setIsLoading(true);
    try {
      // Get destination-specific pricing
      const pricing = getDestinationPricing(destination);
      
      // Load flight options (destination-specific)
      const flights: FlightOption[] = [
        {
          id: 'flight_1',
          airline: getAirlineName(destination, 0),
          price: pricing.flights[0],
          duration: getFlightDuration(destination, 'direct'),
          departure: '08:30',
          arrival: '21:00',
          stops: 0,
          aircraft: 'Boeing 787-9'
        },
        {
          id: 'flight_2',
          airline: getAirlineName(destination, 1),
          price: pricing.flights[1],
          duration: getFlightDuration(destination, 'one-stop'),
          departure: '14:20',
          arrival: '13:05',
          stops: 1,
          aircraft: 'Airbus A350'
        },
        {
          id: 'flight_3',
          airline: getAirlineName(destination, 2),
          price: pricing.flights[2],
          duration: getFlightDuration(destination, 'premium'),
          departure: '10:15',
          arrival: '08:30',
          stops: 0,
          aircraft: 'Boeing 777-300'
        }
      ];

      // Load hotel options (destination-specific)
      const hotels: HotelOption[] = [
        {
          id: 'hotel_1',
          name: getHotelName(destination, 'mid'),
          rating: 4.5,
          pricePerNight: pricing.hotels[0],
          totalPrice: pricing.hotels[0] * tripDuration,
          area: 'Premium Area',
          amenities: ['Free WiFi', 'Pool', 'Restaurant', 'Beach/City Access'],
          image: '/images/hotel-placeholder.jpg',
          description: `Premium hotel in the heart of ${destination.split(',')[0]} with excellent amenities`
        },
        {
          id: 'hotel_2',
          name: getHotelName(destination, 'budget'),
          rating: 4.2,
          pricePerNight: pricing.hotels[1],
          totalPrice: pricing.hotels[1] * tripDuration,
          area: 'Central Location',
          amenities: ['Free WiFi', 'Breakfast', 'Concierge'],
          image: '/images/hotel-placeholder.jpg',
          description: `Comfortable hotel with great value in ${destination.split(',')[0]}`
        },
        {
          id: 'hotel_3',
          name: getHotelName(destination, 'luxury'),
          rating: 4.8,
          pricePerNight: pricing.hotels[2],
          totalPrice: pricing.hotels[2] * tripDuration,
          area: 'Luxury District',
          amenities: ['Free WiFi', 'Spa', 'Pool', 'Valet Parking', 'Fine Dining'],
          image: '/images/hotel-placeholder.jpg',
          description: `Luxury resort with world-class service in ${destination.split(',')[0]}`
        }
      ];

      setFlightOptions(flights);
      setHotelOptions(hotels);
      
      // Auto-select first options
      setSelectedFlightId(flights[0]?.id || '');
      setSelectedHotelId(hotels[0]?.id || '');
      
    } catch (error) {
      console.error('Error loading trip options:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveTrip = () => {
    if (!selectedFlightId || !selectedHotelId) {
      alert('🎯 Please select your preferred flight and hotel options first!\n\nThen click "Save Trip" to save your complete vacation plan.');
      return;
    }

    // Track trip saving
    analytics.tripSaved(tripId, budgetData.totalBudget, destination);
    
    if (onSaveTrip) {
      onSaveTrip(tripSelection);
    }
  };

  const handleUseBudget = () => {
    if (!selectedFlightId || !selectedHotelId) {
      alert('🎯 Please select your preferred flight and hotel options first!\n\nThen click "Set Budget" to save your trip budget for expense tracking.');
      return;
    }

    try {
      // Save budget to localStorage
      const budgets = JSON.parse(localStorage.getItem('tripBudgets') || '{}');
      const budgetKey = `${destination}_${startDate}_${endDate}`;
      
      budgets[budgetKey] = {
        ...budgetData,
        tripName: `${destination} Trip`,
        destination,
        startDate,
        endDate,
        travelers,
        savedAt: new Date().toISOString()
      };
      
      localStorage.setItem('tripBudgets', JSON.stringify(budgets));
      
      alert('✅ Budget set successfully!\n\nYour trip budget has been saved and will be used for expense tracking.');
      
      // Optional: Navigate to budget page
      // window.location.href = '/budget';
    } catch (error) {
      console.error('Error setting budget:', error);
      alert('❌ Error setting budget. Please try again.');
    }
  };

  const handleBuyCompleteTrip = () => {
    if (!selectedFlightId || !selectedHotelId) {
      alert('🎯 Please select your preferred flight and hotel options first!\n\nThen click "Buy Complete Trip" to purchase your full vacation package.');
      return;
    }

    const selectedFlight = flightOptions.find(f => f.id === selectedFlightId);
    const selectedHotel = hotelOptions.find(h => h.id === selectedHotelId);

    // Create complete trip package for checkout
    const tripPackage = {
      type: 'complete-trip',
      destination,
      startDate,
      endDate,
      travelers,
      duration: tripDuration,
      selectedFlight,
      selectedHotel,
      budgetBreakdown: budgetData.breakdown,
      totalAmount: budgetData.totalBudget,
      includes: {
        flights: true,
        accommodation: true,
        meals: true,
        activities: true,
        transport: true,
        emergency_buffer: true
      }
    };

    // Navigate to checkout with complete trip
    const totalTravelers = (travelers.adults || 0) + (travelers.kids || 0);
    const checkoutUrl = `/booking/checkout?${new URLSearchParams({
      type: 'complete-trip',
      item: encodeURIComponent(JSON.stringify(tripPackage)),
      price: budgetData.totalBudget.toString(),
      destination: destination,
      travelers: totalTravelers.toString()
    }).toString()}`;
    
    // Track purchase intent
    analytics.tripPlanned(destination, { departure: startDate, return: endDate }, travelers.adults);
    
    window.location.href = checkoutUrl;
  };

  const handleAddFlightToCart = (flight: FlightOption) => {
    // Add flight to cart (stored in localStorage)
    try {
      const cart = JSON.parse(localStorage.getItem('travelCart') || '[]');
      const flightItem = {
        id: `flight_${flight.id}_${Date.now()}`,
        type: 'flight',
        destination,
        flight,
        travelers,
        totalPrice: flight.price * travelers.adults,
        addedAt: new Date().toISOString()
      };
      
      cart.push(flightItem);
      localStorage.setItem('travelCart', JSON.stringify(cart));
      
      alert(`✅ ${flight.airline} flight added to cart!\n\nTotal: $${(flight.price * travelers.adults).toLocaleString()}`);
    } catch (error) {
      console.error('Error adding flight to cart:', error);
      alert('❌ Error adding to cart. Please try again.');
    }
  };

  const handleAddHotelToCart = (hotel: HotelOption) => {
    // Add hotel to cart (stored in localStorage)
    try {
      const cart = JSON.parse(localStorage.getItem('travelCart') || '[]');
      const hotelItem = {
        id: `hotel_${hotel.id}_${Date.now()}`,
        type: 'hotel',
        destination,
        hotel,
        duration: tripDuration,
        travelers,
        totalPrice: hotel.totalPrice,
        addedAt: new Date().toISOString()
      };
      
      cart.push(hotelItem);
      localStorage.setItem('travelCart', JSON.stringify(cart));
      
      alert(`✅ ${hotel.name} added to cart!\n\nTotal: $${hotel.totalPrice.toLocaleString()} for ${tripDuration} nights`);
    } catch (error) {
      console.error('Error adding hotel to cart:', error);
      alert('❌ Error adding to cart. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading trip options...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{destination}</h1>
              <div className="flex items-center space-x-6 text-gray-600 mt-2">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>{new Date(startDate).toLocaleDateString()} - {new Date(endDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  <span>{travelers.adults} adult{travelers.adults !== 1 ? 's' : ''}</span>
                  {travelers.kids > 0 && <span>, {travelers.kids} child{travelers.kids !== 1 ? 'ren' : ''}</span>}
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{tripDuration} day{tripDuration !== 1 ? 's' : ''}</span>
                </div>
              </div>
            </div>
            
            {/* Total Cost Display */}
            <div className="text-right">
              <div className="text-sm text-gray-600">Estimated Total</div>
              <div className="text-3xl font-bold text-green-600">${budgetData.totalBudget.toLocaleString()}</div>
              <div className="text-sm text-gray-500">for {travelers.adults} traveler{travelers.adults !== 1 ? 's' : ''}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Flight Options */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border p-6 mb-8">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Plane className="w-5 h-5 mr-2 text-blue-600" />
                Choose Your Flight
              </h2>
              
              <div className="space-y-4">
                {flightOptions.map((flight) => (
                  <div 
                    key={flight.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedFlightId === flight.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedFlightId(flight.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-gray-900">{flight.airline}</h3>
                          <div className="text-right">
                            <div className="text-xl font-bold text-green-600">${flight.price}</div>
                            <div className="text-sm text-gray-500">per person</div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-gray-500">Departure</div>
                            <div className="font-medium">{flight.departure}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-gray-500">{flight.duration}</div>
                            <div className="text-xs">
                              {flight.stops === 0 ? 'Direct' : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-gray-500">Arrival</div>
                            <div className="font-medium">{flight.arrival}</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between mt-3">
                          <div className="text-xs text-gray-600">
                            {flight.aircraft}
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddFlightToCart(flight);
                            }}
                            className="text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105"
                            style={{
                              backgroundColor: '#3b82f6',
                              color: 'white',
                              border: 'none'
                            }}
                            onMouseEnter={(e) => e.target.style.backgroundColor = '#2563eb'}
                            onMouseLeave={(e) => e.target.style.backgroundColor = '#3b82f6'}
                          >
                            🛒 Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hotel Options */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Hotel className="w-5 h-5 mr-2 text-green-600" />
                Choose Your Hotel
              </h2>
              
              <div className="space-y-4">
                {hotelOptions.map((hotel) => (
                  <div 
                    key={hotel.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedHotelId === hotel.id 
                        ? 'border-green-500 bg-green-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedHotelId(hotel.id)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900">{hotel.name}</h3>
                        <div className="flex items-center mt-1">
                          <div className="flex items-center">
                            {[...Array(Math.floor(hotel.rating))].map((_, i) => (
                              <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                            ))}
                            {hotel.rating % 1 !== 0 && (
                              <Star className="w-4 h-4 text-yellow-400 fill-current opacity-50" />
                            )}
                          </div>
                          <span className="ml-2 text-sm text-gray-600">{hotel.rating} stars</span>
                        </div>
                        <div className="text-sm text-gray-600 mt-1">{hotel.area}</div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-xl font-bold text-green-600">${hotel.pricePerNight}</div>
                        <div className="text-sm text-gray-500">per night</div>
                        <div className="text-sm font-medium text-gray-700">${hotel.totalPrice} total</div>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">{hotel.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-3">
                      {hotel.amenities.slice(0, 4).map((amenity, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 bg-gray-100 text-xs rounded">
                          {amenity === 'Free WiFi' && <Wifi className="w-3 h-3 mr-1" />}
                          {amenity === 'Valet Parking' && <Car className="w-3 h-3 mr-1" />}
                          {amenity}
                        </span>
                      ))}
                      {hotel.amenities.length > 4 && (
                        <span className="text-xs text-gray-500">
                          +{hotel.amenities.length - 4} more
                        </span>
                      )}
                    </div>
                    
                    <div className="flex justify-end">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddHotelToCart(hotel);
                        }}
                        className="text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105"
                        style={{
                          backgroundColor: '#10b981',
                          color: 'white',
                          border: 'none'
                        }}
                        onMouseEnter={(e) => e.target.style.backgroundColor = '#059669'}
                        onMouseLeave={(e) => e.target.style.backgroundColor = '#10b981'}
                      >
                        🛒 Add to Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Budget Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border p-6 sticky top-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <DollarSign className="w-5 h-5 mr-2 text-purple-600" />
                Trip Budget
              </h3>
              
              <div className="space-y-4">
                <div className="bg-blue-50 p-3 rounded-lg mb-4">
                  <div className="text-sm text-blue-700 font-medium mb-1">Base Trip Costs</div>
                  <div className="text-xs text-blue-600">Core flight + accommodation costs</div>
                </div>

                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Flights ({travelers.adults} × ${tripSelection.selectedFlight?.price || 0})</span>
                  <span className="font-medium">${budgetData.breakdown.flights.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Hotels ({tripDuration} nights)</span>
                  <span className="font-medium">${budgetData.breakdown.hotels.toLocaleString()}</span>
                </div>

                <div className="bg-orange-50 p-3 rounded-lg my-4">
                  <div className="text-sm text-orange-700 font-medium mb-1">Additional Estimates</div>
                  <div className="text-xs text-orange-600">Meals, activities, and emergency buffer</div>
                </div>
                
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Emergency Buffer (15%)</span>
                  <span className="font-medium">${budgetData.breakdown.buffer.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Daily Expenses ($100/day)</span>
                  <span className="font-medium">${budgetData.breakdown.dailyExpenses.toLocaleString()}</span>
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold">Complete Trip Budget</span>
                    <span className="text-2xl font-bold text-purple-600">
                      ${budgetData.totalBudget.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Includes flights, hotels, meals, activities & buffer
                  </div>
                </div>
              </div>

              {/* Buy Complete Trip Button */}
              <button
                onClick={handleBuyCompleteTrip}
                className="w-full mt-6 py-4 px-4 rounded-lg font-bold text-lg transition-all duration-300 text-white shadow-lg hover:shadow-xl transform hover:scale-105"
                style={{
                  backgroundColor: '#7c3aed',
                  color: 'white',
                  border: 'none'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#6d28d9'}
                onMouseLeave={(e) => e.target.style.backgroundColor = '#7c3aed'}
              >
                🛒 Buy Complete Trip - ${budgetData.totalBudget.toLocaleString()}
              </button>
              
              {/* Individual Action Buttons */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <button
                  onClick={handleSaveTrip}
                  className="py-3 px-4 rounded-lg font-semibold transition-all duration-300 text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{
                    backgroundColor: '#8b5cf6',
                    color: 'white',
                    border: 'none'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#7c3aed'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#8b5cf6'}
                >
                  💾 Save Trip
                </button>
                
                <button 
                  onClick={handleUseBudget}
                  className="py-3 px-4 rounded-lg font-semibold transition-all duration-300 text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{
                    backgroundColor: '#3b82f6',
                    color: 'white',
                    border: 'none'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#2563eb'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#3b82f6'}
                >
                  📊 Set Budget
                </button>
              </div>
              
              <div className="mt-4 text-center">
                <p className="text-xs text-gray-500">
                  Complete trip includes flights, hotels, meals & activities
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Travel Hacks and Price Tracking */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mt-8">
          {/* Travel Hacks Panel */}
          <TravelHacksPanel 
            origin="Vancouver"
            destination={destination}
          />
          
          {/* Price Tracking Panel */}
          <PriceTrackingPanel
            origin="Vancouver"
            destination={destination}
            departureDate={startDate}
            returnDate={endDate}
            currentPrice={tripSelection.selectedFlight?.price || 850}
          />
        </div>

        {/* Booking Options */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Flight Booking */}
          <BookingOptionsPanel
            productType="flight"
            origin="Vancouver"
            destination={destination}
            dates={{ departure: startDate, return: endDate }}
            travelers={travelers}
            estimatedPrice={tripSelection.selectedFlight?.price || 850}
          />
          
          {/* Hotel Booking */}
          <BookingOptionsPanel
            productType="hotel"
            destination={destination}
            dates={{ departure: startDate, return: endDate }}
            travelers={travelers}
            estimatedPrice={tripSelection.selectedHotel?.totalPrice || 600}
          />
        </div>
      </div>
    </div>
  );
}
