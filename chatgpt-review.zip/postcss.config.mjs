// Temporarily disable PostCSS plugins to fix CSS parsing issues
const config = {
  plugins: {},
};

export default config;